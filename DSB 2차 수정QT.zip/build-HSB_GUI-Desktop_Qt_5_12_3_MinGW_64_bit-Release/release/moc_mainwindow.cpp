/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../src/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[21];
    char stringdata0[307];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 9), // "procStart"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 8), // "procStop"
QT_MOC_LITERAL(4, 31, 13), // "processOutput"
QT_MOC_LITERAL(5, 45, 12), // "processError"
QT_MOC_LITERAL(6, 58, 11), // "handleState"
QT_MOC_LITERAL(7, 70, 15), // "onActionAyarlar"
QT_MOC_LITERAL(8, 86, 13), // "onActionAbout"
QT_MOC_LITERAL(9, 100, 24), // "onDefaultParamCheckState"
QT_MOC_LITERAL(10, 125, 14), // "Qt::CheckState"
QT_MOC_LITERAL(11, 140, 5), // "state"
QT_MOC_LITERAL(12, 146, 17), // "prepareParameters"
QT_MOC_LITERAL(13, 164, 23), // "isComboParametreEnabled"
QT_MOC_LITERAL(14, 188, 10), // "catchError"
QT_MOC_LITERAL(15, 199, 22), // "QProcess::ProcessError"
QT_MOC_LITERAL(16, 222, 3), // "err"
QT_MOC_LITERAL(17, 226, 21), // "on_btnAyarlar_clicked"
QT_MOC_LITERAL(18, 248, 19), // "on_btnAbout_clicked"
QT_MOC_LITERAL(19, 268, 19), // "on_btnStart_clicked"
QT_MOC_LITERAL(20, 288, 18) // "on_btnStop_clicked"

    },
    "MainWindow\0procStart\0\0procStop\0"
    "processOutput\0processError\0handleState\0"
    "onActionAyarlar\0onActionAbout\0"
    "onDefaultParamCheckState\0Qt::CheckState\0"
    "state\0prepareParameters\0isComboParametreEnabled\0"
    "catchError\0QProcess::ProcessError\0err\0"
    "on_btnAyarlar_clicked\0on_btnAbout_clicked\0"
    "on_btnStart_clicked\0on_btnStop_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   84,    2, 0x0a /* Public */,
       3,    0,   85,    2, 0x0a /* Public */,
       4,    0,   86,    2, 0x0a /* Public */,
       5,    0,   87,    2, 0x0a /* Public */,
       6,    0,   88,    2, 0x0a /* Public */,
       7,    0,   89,    2, 0x0a /* Public */,
       8,    0,   90,    2, 0x0a /* Public */,
       9,    1,   91,    2, 0x0a /* Public */,
      12,    1,   94,    2, 0x0a /* Public */,
      14,    1,   97,    2, 0x0a /* Public */,
      17,    0,  100,    2, 0x08 /* Private */,
      18,    0,  101,    2, 0x08 /* Private */,
      19,    0,  102,    2, 0x08 /* Private */,
      20,    0,  103,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::QStringList, QMetaType::Bool,   13,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->procStart(); break;
        case 1: _t->procStop(); break;
        case 2: _t->processOutput(); break;
        case 3: _t->processError(); break;
        case 4: _t->handleState(); break;
        case 5: _t->onActionAyarlar(); break;
        case 6: _t->onActionAbout(); break;
        case 7: _t->onDefaultParamCheckState((*reinterpret_cast< Qt::CheckState(*)>(_a[1]))); break;
        case 8: { QStringList _r = _t->prepareParameters((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->catchError((*reinterpret_cast< QProcess::ProcessError(*)>(_a[1]))); break;
        case 10: _t->on_btnAyarlar_clicked(); break;
        case 11: _t->on_btnAbout_clicked(); break;
        case 12: _t->on_btnStart_clicked(); break;
        case 13: _t->on_btnStop_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
