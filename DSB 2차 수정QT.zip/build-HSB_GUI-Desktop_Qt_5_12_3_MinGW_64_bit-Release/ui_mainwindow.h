/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionAyarlar;
    QAction *actionAbout;
    QWidget *centralWidget;
    QPushButton *btnStop;
    QPushButton *btnStart;
    QComboBox *comboParametre;
    QPushButton *btnAbout;
    QPushButton *btnAyarlar;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(511, 770);
        MainWindow->setMinimumSize(QSize(511, 770));
        MainWindow->setMaximumSize(QSize(511, 770));
        MainWindow->setContextMenuPolicy(Qt::DefaultContextMenu);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        actionAyarlar = new QAction(MainWindow);
        actionAyarlar->setObjectName(QString::fromUtf8("actionAyarlar"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/images/settings-gears-button.png"), QSize(), QIcon::Normal, QIcon::On);
        actionAyarlar->setIcon(icon);
        actionAyarlar->setVisible(true);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/images/info-button.png"), QSize(), QIcon::Normal, QIcon::On);
        actionAbout->setIcon(icon1);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        btnStop = new QPushButton(centralWidget);
        btnStop->setObjectName(QString::fromUtf8("btnStop"));
        btnStop->setEnabled(true);
        btnStop->setGeometry(QRect(70, 100, 371, 371));
        btnStop->setStyleSheet(QString::fromUtf8("/*background-image:url(:/images/images/papers__1.jpg);*/\n"
"\n"
"/*background-image:url(:/images/images/icon.ico);*/\n"
""));
        btnStop->setAutoDefault(false);
        btnStop->setFlat(true);
        btnStart = new QPushButton(centralWidget);
        btnStart->setObjectName(QString::fromUtf8("btnStart"));
        btnStart->setEnabled(true);
        btnStart->setGeometry(QRect(70, 100, 371, 371));
        btnStart->setMaximumSize(QSize(1555, 1555));
        btnStart->setStyleSheet(QString::fromUtf8(""));
        btnStart->setAutoDefault(false);
        btnStart->setFlat(true);
        comboParametre = new QComboBox(centralWidget);
        comboParametre->setObjectName(QString::fromUtf8("comboParametre"));
        comboParametre->setGeometry(QRect(230, 540, 61, 31));
        btnAbout = new QPushButton(centralWidget);
        btnAbout->setObjectName(QString::fromUtf8("btnAbout"));
        btnAbout->setGeometry(QRect(260, 540, 251, 231));
        btnAbout->setMaximumSize(QSize(1555, 1555));
        btnAbout->setStyleSheet(QString::fromUtf8(""));
        btnAbout->setFlat(true);
        btnAyarlar = new QPushButton(centralWidget);
        btnAyarlar->setObjectName(QString::fromUtf8("btnAyarlar"));
        btnAyarlar->setGeometry(QRect(0, 540, 251, 231));
        btnAyarlar->setMaximumSize(QSize(1555, 1555));
        btnAyarlar->setStyleSheet(QString::fromUtf8("background-image:url(:/imagss/images/test1.png);"));
        btnAyarlar->setFlat(true);
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);
        label->setGeometry(QRect(250, 540, 261, 231));
        label->setStyleSheet(QString::fromUtf8("background:rgb(77,77,77);"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 0, 511, 31));
        label_2->setMinimumSize(QSize(511, 31));
        label_2->setMaximumSize(QSize(511, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Bahnschrift SemiBold"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);
        label_2->setMouseTracking(true);
        label_2->setStyleSheet(QString::fromUtf8("color:rgb(255,255,255);\n"
"background:rgb(77,77,77);"));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(0, 30, 511, 511));
        label_3->setStyleSheet(QString::fromUtf8("background-image:url(:/images/images/giphy.gif);"));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setEnabled(true);
        label_4->setGeometry(QRect(0, 540, 251, 231));
        label_4->setStyleSheet(QString::fromUtf8("background:rgb(77,77,77);"));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(360, 630, 51, 51));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(100, 630, 51, 51));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(150, 260, 211, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Segoe UI Black"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label_7->setFont(font1);
        label_7->setAlignment(Qt::AlignCenter);
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(230, 370, 51, 51));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(230, 370, 51, 51));
        MainWindow->setCentralWidget(centralWidget);
        label_9->raise();
        label_3->raise();
        comboParametre->raise();
        label->raise();
        label_2->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        btnAyarlar->raise();
        btnAbout->raise();
        label_7->raise();
        btnStop->raise();
        btnStart->raise();
        label_8->raise();

        retranslateUi(MainWindow);

        btnStop->setDefault(false);
        btnStart->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        actionAyarlar->setText(QApplication::translate("MainWindow", "Ayarlar", nullptr));
        actionAbout->setText(QApplication::translate("MainWindow", "Hakk\304\261nda", nullptr));
#ifndef QT_NO_TOOLTIP
        actionAbout->setToolTip(QApplication::translate("MainWindow", "Hakk\304\261nda", nullptr));
#endif // QT_NO_TOOLTIP
        btnStop->setText(QString());
        btnStart->setText(QString());
        btnAbout->setText(QString());
        btnAyarlar->setText(QString());
        label->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", "       DSB", nullptr));
#ifndef QT_NO_TOOLTIP
        label_3->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", nullptr));
#endif // QT_NO_TOOLTIP
        label_3->setText(QString());
        label_4->setText(QString());
        label_5->setText(QString());
        label_6->setText(QString());
        label_7->setText(QApplication::translate("MainWindow", "START", nullptr));
        label_8->setText(QString());
        label_9->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
