/********************************************************************************
** Form generated from reading UI file 'settings.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGS_H
#define UI_SETTINGS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Settings
{
public:
    QVBoxLayout *verticalLayout_2;
    QTabWidget *settingWidget;
    QWidget *paramTab;
    QGridLayout *gridLayout_5;
    QCheckBox *checkCustomParam;
    QCheckBox *checkDefaultParam;
    QGroupBox *paramBox;
    QVBoxLayout *verticalLayout_3;
    QTabWidget *tabWidget;
    QWidget *param1;
    QVBoxLayout *verticalLayout;
    QCheckBox *checkR;
    QHBoxLayout *horizontalLayout;
    QCheckBox *checkF;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_3;
    QCheckBox *checkE;
    QSpacerItem *horizontalSpacer_5;

    void setupUi(QWidget *Settings)
    {
        if (Settings->objectName().isEmpty())
            Settings->setObjectName(QString::fromUtf8("Settings"));
        Settings->resize(672, 526);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Settings->sizePolicy().hasHeightForWidth());
        Settings->setSizePolicy(sizePolicy);
        Settings->setMinimumSize(QSize(672, 526));
        Settings->setMaximumSize(QSize(672, 526));
        verticalLayout_2 = new QVBoxLayout(Settings);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        settingWidget = new QTabWidget(Settings);
        settingWidget->setObjectName(QString::fromUtf8("settingWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(settingWidget->sizePolicy().hasHeightForWidth());
        settingWidget->setSizePolicy(sizePolicy1);
        paramTab = new QWidget();
        paramTab->setObjectName(QString::fromUtf8("paramTab"));
        gridLayout_5 = new QGridLayout(paramTab);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        checkCustomParam = new QCheckBox(paramTab);
        checkCustomParam->setObjectName(QString::fromUtf8("checkCustomParam"));

        gridLayout_5->addWidget(checkCustomParam, 1, 0, 1, 1);

        checkDefaultParam = new QCheckBox(paramTab);
        checkDefaultParam->setObjectName(QString::fromUtf8("checkDefaultParam"));
        checkDefaultParam->setChecked(true);

        gridLayout_5->addWidget(checkDefaultParam, 0, 0, 1, 1);

        paramBox = new QGroupBox(paramTab);
        paramBox->setObjectName(QString::fromUtf8("paramBox"));
        paramBox->setEnabled(true);
        verticalLayout_3 = new QVBoxLayout(paramBox);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        tabWidget = new QTabWidget(paramBox);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setEnabled(true);
        tabWidget->setTabShape(QTabWidget::Rounded);
        tabWidget->setElideMode(Qt::ElideRight);
        param1 = new QWidget();
        param1->setObjectName(QString::fromUtf8("param1"));
        verticalLayout = new QVBoxLayout(param1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        checkR = new QCheckBox(param1);
        checkR->setObjectName(QString::fromUtf8("checkR"));

        verticalLayout->addWidget(checkR);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        checkF = new QCheckBox(param1);
        checkF->setObjectName(QString::fromUtf8("checkF"));

        horizontalLayout->addWidget(checkF);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        checkE = new QCheckBox(param1);
        checkE->setObjectName(QString::fromUtf8("checkE"));

        horizontalLayout_3->addWidget(checkE);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_5);


        verticalLayout->addLayout(horizontalLayout_3);

        tabWidget->addTab(param1, QString());

        verticalLayout_3->addWidget(tabWidget);


        gridLayout_5->addWidget(paramBox, 3, 0, 1, 1);

        settingWidget->addTab(paramTab, QString());

        verticalLayout_2->addWidget(settingWidget);


        retranslateUi(Settings);

        settingWidget->setCurrentIndex(0);
        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Settings);
    } // setupUi

    void retranslateUi(QWidget *Settings)
    {
        Settings->setWindowTitle(QApplication::translate("Settings", "Form", nullptr));
        checkCustomParam->setText(QApplication::translate("Settings", "\303\226zel Parametre Kullan", nullptr));
        checkDefaultParam->setText(QApplication::translate("Settings", "Haz\304\261r Parametre Kullan", nullptr));
        paramBox->setTitle(QApplication::translate("Settings", "Parametreler", nullptr));
        checkR->setText(QApplication::translate("Settings", "GET,POST \354\231\200 URL \354\202\254\354\235\264 \352\263\265\353\260\261 \354\266\224\352\260\200", nullptr));
        checkF->setText(QApplication::translate("Settings", "HTTP fragmentation && Redirect (port 302) \352\270\260\353\212\245", nullptr));
        checkE->setText(QApplication::translate("Settings", "DNS over HTTPS && HTTPS fragmentation(DNS \354\225\224\355\230\270\354\231\200 \353\260\217 \355\214\250\355\202\267 \353\213\250\355\216\270\355\231\224 \353\217\231\354\213\234 \354\240\201\354\232\251)", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(param1), QApplication::translate("Settings", "Parametre 1", nullptr));
        settingWidget->setTabText(settingWidget->indexOf(paramTab), QApplication::translate("Settings", "Parametre Ayarlar\304\261", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Settings: public Ui_Settings {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGS_H
