/********************************************************************************
** Form generated from reading UI file 'about.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_H
#define UI_ABOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_About
{
public:
    QGridLayout *gridLayout;
    QLabel *aboutLabel;
    QLabel *iconLabel;

    void setupUi(QDialog *About)
    {
        if (About->objectName().isEmpty())
            About->setObjectName(QString::fromUtf8("About"));
        About->resize(350, 470);
        About->setMinimumSize(QSize(350, 390));
        About->setMaximumSize(QSize(318, 500));
        gridLayout = new QGridLayout(About);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        aboutLabel = new QLabel(About);
        aboutLabel->setObjectName(QString::fromUtf8("aboutLabel"));
        aboutLabel->setMinimumSize(QSize(256, 0));
        aboutLabel->setMaximumSize(QSize(16777215, 300));
        aboutLabel->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(aboutLabel, 2, 0, 1, 1);

        iconLabel = new QLabel(About);
        iconLabel->setObjectName(QString::fromUtf8("iconLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(iconLabel->sizePolicy().hasHeightForWidth());
        iconLabel->setSizePolicy(sizePolicy);
        iconLabel->setMinimumSize(QSize(276, 276));
        iconLabel->setMaximumSize(QSize(256, 256));
        iconLabel->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(iconLabel, 1, 0, 1, 1);


        retranslateUi(About);

        QMetaObject::connectSlotsByName(About);
    } // setupUi

    void retranslateUi(QDialog *About)
    {
        About->setWindowTitle(QApplication::translate("About", "Dialog", nullptr));
        aboutLabel->setText(QApplication::translate("About", "<html><head/><body><p align=\"center\"><br/></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Information DSB GUI</span></p><p align=\"center\"><span style=\" font-family:'\352\265\264\353\246\274,gulim,helvetica,sans-serif'; color:#242424;\">Cheif T. </span>Developer : <span style=\" font-weight:600;\">Lee Sang Kyu</span></p><p align=\"center\">GUI Developer : <span style=\" font-weight:600;\">Jeong Bong Seong</span></p><p align=\"center\">Credits</p><p align=\"center\"><span style=\" text-decoration: underline;\">Dankook Univ/DSB Team</span></p></body></html>", nullptr));
        iconLabel->setText(QApplication::translate("About", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class About: public Ui_About {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_H
