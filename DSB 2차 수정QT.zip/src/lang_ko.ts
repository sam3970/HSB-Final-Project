<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ko_KR">
<context>
    <name>About</name>
    <message>
        <location filename="about.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;GoodByeDPI GUI&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;Geliştirici (Developer): &lt;span style=&quot; font-weight:600;&quot;&gt;hex4d0r&lt;/span&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; text-decoration: underline;&quot;&gt;Kaynak Kod&lt;/span&gt; (Source Code)&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;a href=&quot;https://github.com/hex4d0r/GUI-for-GoodbyeDPI&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;GitHub&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;Bağış(Support)&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;a href=&quot;https://www.patreon.com/hex4d0r&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;Patreon&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;Credits&lt;/p&gt;&lt;p align=&quot;center&quot;&gt;&lt;a href=&quot;https://github.com/ValdikSS/GoodbyeDPI&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;ValdikSS/GoodByeDPI&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="about.ui" line="66"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="23"/>
        <location filename="mainwindow.cpp" line="22"/>
        <source>Başlat</source>
        <translation type="unfinished">시작</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="30"/>
        <location filename="mainwindow.cpp" line="23"/>
        <source>Durdur</source>
        <translation type="unfinished">중지</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="39"/>
        <source>Parametre Listesi</source>
        <translation type="unfinished">인자 목록</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="64"/>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="98"/>
        <location filename="mainwindow.cpp" line="24"/>
        <source>Ayarlar</source>
        <translation type="unfinished">설정</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="111"/>
        <location filename="mainwindow.ui" line="114"/>
        <source>Hakkında</source>
        <translation type="unfinished">정보</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="19"/>
        <source>Gizle</source>
        <translation type="unfinished">숨기기</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>Göster</source>
        <translation type="unfinished">보이기</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="21"/>
        <source>Çıkış</source>
        <translation type="unfinished">나가기</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="90"/>
        <source>all_dnsredir (Tavsiye Edilen)</source>
        <translation type="unfinished">all_dnsredir (추천)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="140"/>
        <source>Arka planda çalışıyor.</source>
        <translation type="unfinished">백그라운드에서 동작.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="161"/>
        <source>Başlatıldı.</source>
        <translation type="unfinished">시작함.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="195"/>
        <source>[-] Durduruldu</source>
        <translation type="unfinished">[-] 멈춤</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="203"/>
        <source>[+] Başlatıldı
[+] PID:</source>
        <translation type="unfinished">[+] Started
[+] PID:</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="settings.ui" line="32"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="48"/>
        <source>Parametre Ayarları</source>
        <translation type="unfinished">인자 설정</translation>
    </message>
    <message>
        <location filename="settings.ui" line="54"/>
        <source>Hazır Parametre Kullan</source>
        <translation type="unfinished">빠른 인자 사용</translation>
    </message>
    <message>
        <location filename="settings.ui" line="64"/>
        <source>Özel Parametre Kullan</source>
        <translation type="unfinished">커스텀 인자 사용</translation>
    </message>
    <message>
        <location filename="settings.ui" line="74"/>
        <source>Parametreler</source>
        <translation type="unfinished">인자들</translation>
    </message>
    <message>
        <location filename="settings.ui" line="93"/>
        <source>Parametre 1</source>
        <translation type="unfinished">인자 1</translation>
    </message>
    <message>
        <location filename="settings.ui" line="99"/>
        <source>[-p] block passive DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="106"/>
        <source>[-r] replace host with hoSt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="113"/>
        <source>[-s] remove space between host header and its value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="120"/>
        <source>[-m] mix Host header case (test.com -&gt; tEsT.cOm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="129"/>
        <source>[-f] set HTTP fragmentation to value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="160"/>
        <source>[-k] enable HTTP persistent (keep-alive) fragmentation and set it to value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="189"/>
        <source>[-n] do not wait for first segment ACK when -k is enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="198"/>
        <source>[-e] set HTTPS fragmentation to value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="227"/>
        <source>[-a] additional space between Method and Request-URI (enables -s, may break sites)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="234"/>
        <source>[-w] try to find and parse HTTP traffic on all processed ports (not only on port 80)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="243"/>
        <source>[--port] additional TCP port to perform fragmentation on (and HTTP tricks with -w):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="274"/>
        <source>[--ip-id] handle additional IP ID (decimal, drop redirects and TCP RSTs with this ID):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="287"/>
        <source>Parametre 2</source>
        <translation type="unfinished">인자 2</translation>
    </message>
    <message>
        <location filename="settings.ui" line="295"/>
        <source>[--dns-addr] redirect UDP DNS requests to the supplied IP address (experimental):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="302"/>
        <source>208.67.220.220</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="313"/>
        <source>[--dns-port] redirect UDP DNS requests to the supplied port (53 by default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="353"/>
        <source>[--dnsv6-addr] redirect UDPv6 DNS requests to the supplied IPv6 address (experimental):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="360"/>
        <source>2a02:6b8::feed:0ff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="371"/>
        <source>[--dnsv6-port] redirect UDPv6 DNS requests to the supplied port (53 by default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="409"/>
        <source>[--blacklist] perform HTTP tricks only to host names and subdomains from
                          supplied text file. This option can be supplied multiple times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="418"/>
        <source>Hizli Ayarlar</source>
        <translation type="unfinished">간편 설정</translation>
    </message>
    <message>
        <location filename="settings.ui" line="424"/>
        <source>Hazir ayarlar</source>
        <translation type="unfinished">기본 설정</translation>
    </message>
    <message>
        <location filename="settings.ui" line="430"/>
        <source>[-1] -p -r -s -f 2 -k 2 -n -e 2 (most compatible mode, default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="437"/>
        <source>[-3] -p -r -s -e 40 (better speed for HTTP and HTTPS)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="444"/>
        <source>[-2] -p -r -s -f 2 -k 2 -n -e 40 (better speed for HTTPS yet still compatible)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="451"/>
        <source>[-4] -p -r -s (best speed)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="461"/>
        <source>Hizli ayarlari aktif et</source>
        <translation type="unfinished">간편 설정 켜기</translation>
    </message>
    <message>
        <location filename="settings.ui" line="476"/>
        <source>Çalışma Ayarları</source>
        <translation type="unfinished">소프트웨어 설정</translation>
    </message>
    <message>
        <location filename="settings.ui" line="482"/>
        <source>Çalışma Saatleri Ayarla (Sonraki guncellemede gelecek.)</source>
        <translation type="unfinished">자동시작 스케줄 (다음 업데이트에 추가 예정)</translation>
    </message>
    <message>
        <location filename="settings.ui" line="489"/>
        <source>Sistem Tepsisine Küçült</source>
        <translation type="unfinished">트레이로 최소화</translation>
    </message>
    <message>
        <location filename="settings.ui" line="499"/>
        <source>Başlangıçta Otomatik Çalıştır</source>
        <translation type="unfinished">부팅시 시작</translation>
    </message>
    <message>
        <location filename="settings.ui" line="509"/>
        <source>Çalışma Saatleri</source>
        <translation type="unfinished">시간 설정</translation>
    </message>
    <message>
        <location filename="settings.ui" line="521"/>
        <location filename="settings.ui" line="534"/>
        <source>HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="548"/>
        <source>Bildirimleri Kapat</source>
        <translation type="unfinished">알림 끄기</translation>
    </message>
</context>
</TS>
